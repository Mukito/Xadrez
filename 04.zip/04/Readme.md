# Jogo de Xadrez com Python

Um jogo de xadrez completo desenvolvido em Python, utilizando a biblioteca `python-chess` para a lógica do jogo e renderização SVG para uma interface gráfica de alta qualidade.

## Funcionalidades

- **Lógica de Xadrez Completa**: Utiliza a biblioteca `python-chess`, que implementa todas as regras do xadrez, incluindo:
  - Movimentos válidos para todas as peças
  - Verificação de xeque e xeque-mate
  - Roque (castling)
  - Promoção de peão
  - En passant
  - Detecção de afogamento e outras condições de fim de jogo

- **Interface Gráfica Interativa**: Desenvolvida com Pygame e renderização SVG para uma visualização clara e profissional do tabuleiro.

- **Modo Livre**: Permite que um jogador jogue contra si mesmo, movendo ambas as peças (brancas e pretas).

## Instalação

### Pré-requisitos

- Python 3.7 ou superior
- pip (gerenciador de pacotes Python)

### Passos de Instalação

1. **Clone ou baixe o projeto:**
   ```bash
   git clone <url-do-repositorio>
   cd chess-game
   ```

2. **Instale as dependências:**
   ```bash
   pip install -r requirements.txt
   ```

   Ou instale manualmente:
   ```bash
   pip install pygame python-chess cairosvg
   ```

## Uso

Para executar o jogo:

```bash
python3 main.py
```

### Controles

- **Selecionar Peça**: Clique em uma peça para selecioná-la. As casas verdes mostram os movimentos possíveis.
- **Mover Peça**: Clique em uma casa verde para mover a peça selecionada para lá.
- **Resetar Jogo**: Clique no botão "Resetar" para reiniciar o jogo.
- **Promoção de Peão**: Quando um peão atinge a última fileira, uma interface de promoção aparece para escolher a peça (Rainha, Torre, Bispo ou Cavalo).

## Estrutura do Projeto

```
chess-game/
├── main.py          # Ponto de entrada do jogo
├── gui.py           # Interface gráfica com Pygame e SVG
├── game.py          # Lógica do jogo usando python-chess
├── board.py         # Arquivo vazio (substituído por python-chess)
├── pieces.py        # Arquivo vazio (substituído por python-chess)
├── requirements.txt # Dependências do projeto
└── README.md        # Este arquivo
```

## Dependências

- **pygame**: Biblioteca para criar a interface gráfica.
- **python-chess**: Biblioteca completa para lógica de xadrez.
- **cairosvg**: Biblioteca para renderizar SVG em PNG.

https://github.com/tschoonj/GTK-for-Windows-Runtime-Environment-Installer/releases

## Funcionalidades Implementadas

✅ Movimentos válidos para todas as peças
✅ Verificação de xeque e xeque-mate
✅ Roque (castling)
✅ Promoção de peão
✅ Detecção de afogamento
✅ Interface gráfica interativa
✅ Renderização SVG de alta qualidade
✅ Modo livre (um jogador contra si mesmo)

## Funcionalidades Futuras

- [ ] Modo de dois jogadores em rede
- [ ] Integração com motores de xadrez (Stockfish)
- [ ] Histórico de movimentos
- [ ] Análise de posições
- [ ] Temas personalizáveis

## Contribuição

Contribuições são bem-vindas! Sinta-se livre para abrir issues ou pull requests.

## Licença

Este projeto é licenciado sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.

## Autor

Desenvolvido com ❤️ em Python.

## Suporte

Se encontrar algum problema ou tiver dúvidas, abra uma issue no repositório do projeto.



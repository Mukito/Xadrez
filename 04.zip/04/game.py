import chess

class Game:
    def __init__(self):
        # Inicializa o tabuleiro do python-chess
        self.board = chess.Board()
        
    def make_move(self, uci_move):
        """
        Tenta fazer um movimento no formato UCI (e.g., 'e2e4').
        Retorna True se o movimento for legal e realizado, False caso contrário.
        """
        try:
            move = chess.Move.from_uci(uci_move)
            if move in self.board.legal_moves:
                self.board.push(move)
                return True
            else:
                print(f"Movimento ilegal: {uci_move}")
                return False
        except ValueError:
            print(f"Formato de movimento inválido: {uci_move}")
            return False

    def reset_game(self):
        """
        Reinicia o jogo para a posição inicial.
        """
        self.board.reset()

    @property
    def current_turn(self):
        """
        Retorna a cor do jogador atual ('white' ou 'black').
        """
        return 'white' if self.board.turn == chess.WHITE else 'black'

    def is_game_over(self):
        """
        Verifica se o jogo terminou (xeque-mate, afogamento, etc.).
        """
        return self.board.is_game_over()

    def get_status(self):
        """
        Retorna o status do jogo.
        """
        if self.board.is_checkmate():
            return "Xeque-mate!"
        elif self.board.is_stalemate():
            return "Afogamento!"
        elif self.board.is_insufficient_material():
            return "Material Insuficiente!"
        elif self.board.is_fivefold_repetition():
            return "Repetição Quíntupla!"
        elif self.board.is_seventyfive_moves():
            return "Regra dos 75 Movimentos!"
        elif self.board.is_check():
            return "Xeque!"
        else:
            return "Em jogo"
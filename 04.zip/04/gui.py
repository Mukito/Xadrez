import pygame
import sys
import io
import chess
import chess.svg
from cairosvg import svg2png
from game import Game

class ChessGUI:
    def __init__(self):
        pygame.init()
        self.BOARD_SIZE = 640
        self.SQUARE_SIZE = self.BOARD_SIZE // 8
        self.screen = pygame.display.set_mode((self.BOARD_SIZE, self.BOARD_SIZE + 100))
        pygame.display.set_caption("Jogo de Xadrez")
        
        # Cores
        self.TEXT_COLOR = (0, 0, 0)
        self.BUTTON_COLOR = (100, 100, 100)
        self.BUTTON_TEXT_COLOR = (255, 255, 255)
        self.PROMOTION_BG_COLOR = (200, 200, 200, 200)
        
        # Fonte
        self.font = pygame.font.Font(None, 36)
        self.promotion_font = pygame.font.Font(None, 28)
        
        # Jogo
        self.game = Game()
        
        # Estado da interface
        self.selected_square = None
        self.possible_moves = []
        self.promotion_pending = False
        self.promotion_from_square = None
        self.promotion_to_square = None
        self.promotion_options = []
        
        # Cache de imagens SVG renderizadas
        self.board_image = None
        self.board_image_rect = None
        
        # Botão de Reset
        self.reset_button_rect = pygame.Rect(self.BOARD_SIZE - 150, self.BOARD_SIZE + 30, 120, 40)
        
        # Renderizar o tabuleiro inicial
        self.render_board()

    def render_board(self):
        """
        Renderiza o tabuleiro do jogo usando SVG e o converte para uma imagem Pygame.
        """
        # Gera o SVG do tabuleiro usando python-chess
        svg_string = chess.svg.board(
            board=self.game.board,
            size=self.BOARD_SIZE,
            coordinates=True,
            arrows=[]
        )
        
        # Converte o SVG para PNG usando cairosvg
        png_bytes = io.BytesIO()
        svg2png(bytestring=svg_string, write_to=png_bytes)
        png_bytes.seek(0)
        
        # Carrega a imagem PNG no Pygame
        self.board_image = pygame.image.load(png_bytes)
        self.board_image_rect = self.board_image.get_rect(topleft=(0, 0))

    def square_to_pixel(self, square):
        """
        Converte um quadrado do tabuleiro (0-63) para coordenadas de pixel.
        """
        row = 7 - (square // 8)  # Inverte a linha para corresponder ao SVG
        col = square % 8
        x = col * self.SQUARE_SIZE + self.SQUARE_SIZE // 2
        y = row * self.SQUARE_SIZE + self.SQUARE_SIZE // 2
        return x, y

    def pixel_to_square(self, x, y):
        """
        Converte coordenadas de pixel para um quadrado do tabuleiro (0-63).
        """
        if 0 <= x < self.BOARD_SIZE and 0 <= y < self.BOARD_SIZE:
            col = x // self.SQUARE_SIZE
            row = y // self.SQUARE_SIZE
            square = (7 - row) * 8 + col  # Inverte a linha para corresponder ao SVG
            return square
        return None

    def get_legal_moves_from_square(self, square):
        """
        Retorna uma lista de quadrados para os quais o jogador pode mover a peça no quadrado fornecido.
        """
        moves = []
        for move in self.game.board.legal_moves:
            if move.from_square == square:
                moves.append(move.to_square)
        return moves

    def draw_board(self):
        """
        Desenha o tabuleiro na tela.
        """
        if self.board_image:
            self.screen.blit(self.board_image, self.board_image_rect)

    def draw_highlights(self):
        """
        Desenha destaques para o quadrado selecionado e os movimentos possíveis.
        """
        if self.selected_square is not None:
            x, y = self.square_to_pixel(self.selected_square)
            pygame.draw.circle(self.screen, (255, 255, 0), (x, y), 10, 3)
        
        for square in self.possible_moves:
            x, y = self.square_to_pixel(square)
            pygame.draw.circle(self.screen, (0, 255, 0), (x, y), 8, 2)

    def draw_info(self):
        """
        Desenha informações do jogo (turno, status, botão de reset).
        """
        info_y = self.BOARD_SIZE + 10
        
        # Turno
        turn_text = f"Turno: {self.game.current_turn.capitalize()}"
        text_surface = self.font.render(turn_text, True, self.TEXT_COLOR)
        self.screen.blit(text_surface, (10, info_y))
        
        # Status do jogo
        status = self.game.get_status()
        status_surface = self.font.render(status, True, (255, 0, 0) if "Xeque" in status else self.TEXT_COLOR)
        self.screen.blit(status_surface, (200, info_y))
        
        # Botão de Reset
        pygame.draw.rect(self.screen, self.BUTTON_COLOR, self.reset_button_rect)
        reset_text = self.font.render("Resetar", True, self.BUTTON_TEXT_COLOR)
        reset_text_rect = reset_text.get_rect(center=self.reset_button_rect.center)
        self.screen.blit(reset_text, reset_text_rect)

    def draw_promotion_options(self):
        """
        Desenha a interface de promoção de peão.
        """
        if not self.promotion_pending:
            return

        # Fundo semi-transparente
        overlay = pygame.Surface((self.BOARD_SIZE, self.BOARD_SIZE), pygame.SRCALPHA)
        overlay.fill(self.PROMOTION_BG_COLOR)
        self.screen.blit(overlay, (0, 0))

        # Opções de promoção: Rainha, Torre, Bispo, Cavalo
        promotion_pieces = [
            ('Q', chess.QUEEN),
            ('R', chess.ROOK),
            ('B', chess.BISHOP),
            ('N', chess.KNIGHT)
        ]
        
        self.promotion_options = []
        
        # Posição central para as opções
        option_width = 60
        option_height = 60
        start_x = (self.BOARD_SIZE - len(promotion_pieces) * option_width) // 2
        start_y = (self.BOARD_SIZE - option_height) // 2

        for i, (symbol, piece_type) in enumerate(promotion_pieces):
            x = start_x + i * option_width
            y = start_y
            rect = pygame.Rect(x, y, option_width, option_height)
            
            # Desenhar fundo do botão
            pygame.draw.rect(self.screen, (200, 200, 200), rect)
            pygame.draw.rect(self.screen, (0, 0, 0), rect, 2)
            
            # Desenhar símbolo
            text_surface = self.promotion_font.render(symbol, True, self.TEXT_COLOR)
            text_rect = text_surface.get_rect(center=rect.center)
            self.screen.blit(text_surface, text_rect)
            
            self.promotion_options.append((piece_type, rect))

    def handle_click(self, pos):
        """
        Lida com cliques do mouse.
        """
        # Se a promoção estiver pendente, lida com a escolha da peça
        if self.promotion_pending:
            for piece_type, rect in self.promotion_options:
                if rect.collidepoint(pos):
                    # Cria o movimento de promoção
                    move = chess.Move(self.promotion_from_square, self.promotion_to_square, piece_type)
                    if move in self.game.board.legal_moves:
                        self.game.board.push(move)
                        self.promotion_pending = False
                        self.promotion_from_square = None
                        self.promotion_to_square = None
                        self.promotion_options = []
                        self.selected_square = None
                        self.possible_moves = []
                        self.render_board()
                        print(f"Peão promovido para {chess.piece_name(piece_type).upper()}!")
                    return
            return  # Ignora cliques fora das opções de promoção

        # Verifica se o clique foi no botão de reset
        if self.reset_button_rect.collidepoint(pos):
            self.game.reset_game()
            self.selected_square = None
            self.possible_moves = []
            self.promotion_pending = False
            self.render_board()
            print("Jogo resetado!")
            return

        # Converte coordenadas de pixel para quadrado do tabuleiro
        x, y = pos
        square = self.pixel_to_square(x, y)
        
        if square is None:
            return

        # Se nenhum quadrado estiver selecionado, seleciona um
        if self.selected_square is None:
            piece = self.game.board.piece_at(square)
            if piece and piece.color == self.game.board.turn:
                self.selected_square = square
                self.possible_moves = self.get_legal_moves_from_square(square)
        else:
            # Se um quadrado estiver selecionado, tenta fazer o movimento
            if square in self.possible_moves:
                # Verifica se é um movimento de promoção
                piece = self.game.board.piece_at(self.selected_square)
                if piece and piece.piece_type == chess.PAWN:
                    # Verifica se o peão está se movendo para a última fileira
                    if (piece.color == chess.WHITE and square >= 56) or \
                       (piece.color == chess.BLACK and square <= 7):
                        # Ativa a interface de promoção
                        self.promotion_pending = True
                        self.promotion_from_square = self.selected_square
                        self.promotion_to_square = square
                        self.selected_square = None
                        self.possible_moves = []
                        return

                # Movimento normal
                move = chess.Move(self.selected_square, square)
                if move in self.game.board.legal_moves:
                    self.game.board.push(move)
                    print(f"Movimento realizado: {chess.square_name(self.selected_square)} -> {chess.square_name(square)}")
                else:
                    print("Movimento inválido!")
                
                self.selected_square = None
                self.possible_moves = []
                self.render_board()
            else:
                # Desseleciona o quadrado anterior e seleciona um novo
                piece = self.game.board.piece_at(square)
                if piece and piece.color == self.game.board.turn:
                    self.selected_square = square
                    self.possible_moves = self.get_legal_moves_from_square(square)
                else:
                    self.selected_square = None
                    self.possible_moves = []

    def run(self):
        """
        Loop principal do jogo.
        """
        clock = pygame.time.Clock()
        running = True
        
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        self.handle_click(event.pos)
            
            self.screen.fill((255, 255, 255))
            
            self.draw_board()
            self.draw_highlights()
            self.draw_info()
            self.draw_promotion_options()
            
            pygame.display.flip()
            clock.tick(60)
        
        pygame.quit()
        sys.exit()

from gui import ChessGUI

if __name__=="__main__":
    app = ChessGUI()
    app.run()
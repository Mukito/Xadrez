class Board:
    def __init__(self):
        self.state = self.create_initial_board()

    def create_initial_board(self):
        """Cria o tabuleiro inicial com as peças nas posições padrão."""
        board = [[" " for _ in range(8)] for _ in range(8)]

        # Peões
        for i in range(8):
            board[1][i] = "pawn_black"
            board[6][i] = "pawn_white"

        # Torres
        board[0][0] = board[0][7] = "rook_black"
        board[7][0] = board[7][7] = "rook_white"

        # Cavalos
        board[0][1] = board[0][6] = "knight_black"
        board[7][1] = board[7][6] = "knight_white"

        # Bispos
        board[0][2] = board[0][5] = "bishop_black"
        board[7][2] = board[7][5] = "bishop_white"

        # Rainha e Rei
        board[0][3] = "queen_black"
        board[0][4] = "king_black"
        board[7][3] = "queen_white"
        board[7][4] = "king_white"

        return board
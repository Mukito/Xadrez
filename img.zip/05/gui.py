import pygame
import os
from board import Board

class ChessGUI:
    def __init__(self):
        pygame.init()
        self.size = 640
        self.square_size = self.size // 8
        self.screen = pygame.display.set_mode((self.size, self.size))
        pygame.display.set_caption("Xadrez")

        self.board = Board()
        self.pieces_images = self.load_piece_images()

    def load_piece_images(self):
        """Carrega todas as imagens de peças em assets/pieces"""
        pieces = {}
        folder = os.path.join("assets", "pieces")

        for color in ["white", "black"]:
            for piece in ["pawn", "rook", "knight", "bishop", "queen", "king"]:
                path = os.path.join(folder, f"{piece}_{color}.png")
                image = pygame.image.load(path).convert_alpha()
                image = pygame.transform.scale(image, (self.square_size, self.square_size))
                pieces[f"{piece}_{color}"] = image

        return pieces

    def draw_board(self):
        colors = [(238, 238, 210), (118, 150, 86)]
        for row in range(8):
            for col in range(8):
                color = colors[(row + col) % 2]
                pygame.draw.rect(
                    self.screen, color,
                    pygame.Rect(col * self.square_size, row * self.square_size, self.square_size, self.square_size)
                )

    def draw_pieces(self):
        for row in range(8):
            for col in range(8):
                piece = self.board.state[row][col]
                if piece != " ":
                    image = self.pieces_images[piece]
                    self.screen.blit(image, (col * self.square_size, row * self.square_size))

    def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            self.draw_board()
            self.draw_pieces()
            pygame.display.flip()

        pygame.quit()